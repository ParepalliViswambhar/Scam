import time

while True:
    print("Running scheduled Python job...")
    time.sleep(10)
