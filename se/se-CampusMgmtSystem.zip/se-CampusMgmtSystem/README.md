# Campus Management System

A Java-based Campus Management System application built with Maven and containerized with Docker.

## Project Overview

This project is a simple Java application that serves as a foundation for a Campus Management System. It demonstrates proper Maven configuration, Docker containerization, and Docker Compose orchestration.

## Features

- Java 21 application with Maven build system
- Docker containerization for easy deployment
- Docker Compose for service orchestration
- Proper JAR packaging with executable manifest
- RESTful service ready architecture

## Prerequisites

- Java 21 or higher
- Maven 3.6 or higher
- Docker Desktop
- Docker Compose

## Project Structure

```
se-CampusMgmtSystem/
├── src/
│   └── main/
│       └── java/
│           └── SE/
│               └── CampusMgmtSyatem/
│                   └── App.java
├── target/
│   └── CampusMgmtSyatem-0.0.1-SNAPSHOT.jar
├── pom.xml
├── Dockerfile
├── docker-compose.yml
└── README.MD
```

## Quick Start

### Using Docker Compose (Recommended)

1. **Build and run the application:**
   ```bash
   docker-compose up --build
   ```

2. **Run in detached mode:**
   ```bash
   docker-compose up -d --build
   ```

3. **Stop the application:**
   ```bash
   docker-compose down
   ```

### Using Docker Commands

1. **Build the Maven project:**
   ```bash
   mvn clean package
   ```

2. **Build the Docker image:**
   ```bash
   docker build -t campus-mgmt-system .
   ```

3. **Run the container:**
   ```bash
   docker run -p 8080:8080 campus-mgmt-system
   ```

## Configuration

### Maven Configuration

The project includes proper Maven configuration with:
- Java 21 compiler plugin
- JAR plugin with main class manifest
- JUnit testing framework

### Docker Configuration

- **Base Image:** OpenJDK 21 JDK Slim
- **Port:** 8080
- **Working Directory:** /app
- **Main Class:** SE.CampusMgmtSyatem.App

### Docker Compose Configuration

- **Service Name:** campus-mgmt-system
- **Container Name:** campus-mgmt-app
- **Port Mapping:** 8080:8080
- **Restart Policy:** unless-stopped
- **Environment:** SPRING_PROFILES_ACTIVE=dev

## Development

### Building the Project

```bash
# Clean and compile
mvn clean compile

# Run tests
mvn test

# Package the application
mvn clean package

# Install dependencies
mvn install
```

### Running Tests

```bash
mvn test
```

## Troubleshooting

### Common Issues

1. **"no main manifest attribute" error:**
   - Ensure the `maven-jar-plugin` is properly configured in `pom.xml`
   - Rebuild the project with `mvn clean package`

2. **Java version mismatch:**
   - Ensure Docker image uses Java 21 (OpenJDK 21)
   - Check that your local Java version matches the Docker image

3. **Docker connection issues:**
   - Ensure Docker Desktop is running
   - Check Docker daemon status with `docker info`

## API Endpoints

Currently, the application outputs:
```
LAB INTERNAL Hello World!
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is for educational purposes as part of a lab internal assignment.

## Contact

For questions or support, please contact the development team.

---

**Note:** This is a foundational project that can be extended with additional features like database integration, REST APIs, user authentication, and more comprehensive campus management functionality.