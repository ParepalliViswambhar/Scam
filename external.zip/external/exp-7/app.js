const express = require('express');
const mongoose = require('mongoose');

const app = express();

app.use(express.static('public'));

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/studentDB');

// Student Schema
const Student = mongoose.model('Student', {
    rollNumber: String,
    name: String,
    email: String,
    department: String,
    year: Number
});

// Search student by roll number
app.get('/api/student', async (req, res) => {
    const student = await Student.findOne({ rollNumber: req.query.rollNumber });
    if (student) {
        res.json(student);
    } else {
        res.status(404).json({ error: 'Student not found' });
    }
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
