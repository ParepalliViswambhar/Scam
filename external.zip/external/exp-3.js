var http = require('http');

var server = http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    
    if (req.url == '/') {
        res.end('<h1>Home Page</h1>');
    }
    else if (req.url == '/student') {
        res.end('<h1>Student Page</h1>');
    }
    else if (req.url == '/admin') {
        res.end('<h1>Admin Page</h1>');
    }
    else {
        res.end('<h1>Invalid Request</h1>');
    }
});

server.listen(8000);
console.log('Server running at http://localhost:8000');