const express = require('express');
const path = require('path');
const mongoose = require('mongoose');

const app = express();
const PORT = 3000;

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/studentDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected successfully'))
.catch(err => console.error('MongoDB connection error:', err));

// Student Schema
const Student = mongoose.model('Student', {
    rollNumber: String,
    name: String,
    email: String,
    department: String,
    year: Number
});

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

// Routes
// Home page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Add new student page
app.get('/page/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

// Search student page
app.get('/page/search', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'search.html'));
});

// Update student page
app.get('/page/update', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'update.html'));
});

// API Routes
// Create - Add new student
app.post('/api/students', async (req, res) => {
    try {
        const { name, rollNumber, email, department, year } = req.body;
        const student = new Student({ name, rollNumber, email, department, year });
        await student.save();
        res.json({ success: true, message: 'Student added successfully', student });
    } catch (error) {
        res.json({ success: false, message: 'Error adding student' });
    }
});

// Read - Get all students
app.get('/api/students', async (req, res) => {
    try {
        const students = await Student.find();
        res.json(students);
    } catch (error) {
        res.json({ success: false, message: 'Error fetching students' });
    }
});

// Read - Search student by roll number
app.get('/api/students/search/:rollNumber', async (req, res) => {
    try {
        const student = await Student.findOne({ rollNumber: req.params.rollNumber });
        if (student) {
            res.json({ success: true, student });
        } else {
            res.json({ success: false, message: 'Student not found' });
        }
    } catch (error) {
        res.json({ success: false, message: 'Error searching student' });
    }
});

// Update - Update student details
app.put('/api/students/:rollNumber', async (req, res) => {
    try {
        const { name, email, department, year } = req.body;
        const student = await Student.findOneAndUpdate(
            { rollNumber: req.params.rollNumber },
            { name, email, department, year },
            { new: true }
        );
        
        if (student) {
            res.json({ success: true, message: 'Student updated successfully', student });
        } else {
            res.json({ success: false, message: 'Student not found' });
        }
    } catch (error) {
        res.json({ success: false, message: 'Error updating student' });
    }
});

// Delete - Delete student
app.delete('/api/students/:rollNumber', async (req, res) => {
    try {
        const student = await Student.findOneAndDelete({ rollNumber: req.params.rollNumber });
        
        if (student) {
            res.json({ success: true, message: 'Student deleted successfully', student });
        } else {
            res.json({ success: false, message: 'Student not found' });
        }
    } catch (error) {
        res.json({ success: false, message: 'Error deleting student' });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
