let arr = [3, 'a', 5, 'b', 2, 5, 'a', 3, 'a', 1, 4, 5];
let count = {};
let max = 0;
let frequent;

for (let i = 0; i < arr.length; i++) {
    count[arr[i]] = (count[arr[i]] || 0) + 1;
    if (count[arr[i]] > max) {
        max = count[arr[i]];
        frequent = arr[i];
    }
}

console.log('Most frequent:', frequent, '(' + max + ' times)');
