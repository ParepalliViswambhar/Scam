object = {
 name: 'Jack',
 age: 25,
 college: 'KMIT',
 year: 3,
 sem: 1
 };
let properties = Object.keys(object)
console.log(properties);