let obj = { name: 'John', age: 30, city: 'New York' };

// Method 1: hasOwnProperty()
console.log('hasOwnProperty:', obj.hasOwnProperty('name'));

// Method 2: in operator
console.log('in operator:', 'name' in obj);

// Method 3: undefined comparison
console.log('undefined check:', obj['name'] !== undefined);
