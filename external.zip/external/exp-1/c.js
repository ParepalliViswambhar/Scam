let arr = [1, 2, 3, 2, 4, 3, 5, 1, 6];
let unique = [];

for (let i = 0; i < arr.length; i++) {
    if (unique.indexOf(arr[i]) === -1) {
        unique.push(arr[i]);
    }
}

console.log('Original:', arr);
console.log('Unique:', unique);
