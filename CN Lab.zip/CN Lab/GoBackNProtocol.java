import java.util.Scanner;

public class GoBackNProtocol {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Total frames: ");
        int totalFrames = sc.nextInt();

        System.out.print("Window size: ");
        int windowSize = sc.nextInt();

        System.out.print("Lost frame number (0 = none): ");
        int lostFrame = sc.nextInt();

        int nextFrame = 1, ack = 1;
        boolean lost = false;

        while (ack <= totalFrames) {
            int end = Math.min(nextFrame + windowSize - 1, totalFrames);
            System.out.println("Send: " + nextFrame + " -> " + end);

            boolean timeout = false;
            for (int i = nextFrame; i <= end; i++) {
                if (i == lostFrame && !lost) {
                    System.out.println("Frame " + i + " lost (no ACK)");
                    timeout = true;
                    lost = true;
                    break;
                } else {
                    System.out.println("ACK " + i);
                    ack = i + 1;
                }
            }

            if (timeout) {
                System.out.println("Timeout -> Resend from " + ack);
                nextFrame = ack;
            } else {
                nextFrame = end + 1;
            }
        }

        System.out.println("All frames sent");
        sc.close();
    }
}
