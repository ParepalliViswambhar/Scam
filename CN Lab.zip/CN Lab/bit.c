#include<stdio.h>
#include<string.h>
void bit_stuff(char data[]){
     char flag[] = "01111110";
     char stuff[100];
     int j=0;
     for(int i=0;i<strlen(flag);i++){
        stuff[j++]=flag[i];
     }
     int cnt=0;
     for(int i=0;i<strlen(data);i++){
        stuff[j++]=data[i];
        if(data[i]=='1'){
            cnt+=1;
            if(cnt==5){
                stuff[j++]='0';
                cnt=0;
            }
        }
        else{
            cnt=0;
        }
     }
     for(int i=0;i<strlen(flag);i++){
        stuff[j++]=flag[i];
     }
     stuff[j]='\0';
     printf("%s",stuff);
}
int main(){
    char data[100];
    printf("Enter data");
    scanf("%s",data);
    bit_stuff(data);
}