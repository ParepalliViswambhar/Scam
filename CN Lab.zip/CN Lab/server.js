const WebSocket = require("ws");
const readline = require("readline");
const wss = new WebSocket.Server({ port: 8080 });
wss.on("connection", ws => {
  ws.on("message", message => {
    console.log("Client:", message.toString());
  });
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  rl.on("line", line => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(line);
    }
  });
});
