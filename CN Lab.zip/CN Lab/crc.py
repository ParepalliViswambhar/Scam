def mod2div(dividend, generator):
    dividend = list(dividend)
    g = len(generator)
    for i in range(len(dividend) - g + 1):
        if dividend[i] == '1':
            for j in range(g):
                dividend[i + j] = str(int(dividend[i + j]) ^ int(generator[j]))
    return "".join(dividend)
data = input("Enter data to be transmitted: ")
gen = input("Enter the Generating polynomial: ")
padded = data + "0" * (len(gen) - 1)
print("Data padded with n-1 zeros :", padded)
work = mod2div(padded, gen)
crc = work[len(data):]
print("CRC or Check value is :", crc)
finalData = data + crc
print("Final data to be sent :", finalData)
recv = input("Enter the received data: ")
print("Data received:", recv)
work = mod2div(recv, gen)
remainder = work[-(len(gen)-1):]
if "1" in remainder:
    print("Error detected")
else:
    print("No error detected")