#include<stdio.h>
#include<string.h>
void char_stuff(char data[]){
    char stuff[100];
    stuff[0]='$';
    for(int i=0;i<strlen(data);i++){
        stuff[i+1]=data[i];
    } 
    stuff[strlen(data)+1]='$';
    stuff[strlen(data) + 2] = '\0';
    printf("%s",stuff);
}
int main(){
    char data[100];
    printf("Enter string:");
    scanf("%s",data);
    char_stuff(data);
}