console.log("Script.js file loaded and running.");

let PRODUCTS = [];
const state = {
  cart: JSON.parse(localStorage.getItem('cart') || '[]'),
  likes: JSON.parse(localStorage.getItem('likes') || '{}'),
  ratings: JSON.parse(localStorage.getItem('ratings') || '{}')
};

/* ---------- Load products.json ---------- */
async function loadProducts() {
  console.log("Attempting to load products.json...");
  try {
    const response = await fetch('products.json');
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    PRODUCTS = await response.json();
    console.log("Successfully loaded products:", PRODUCTS);
  } catch (error) {
    console.error("Could not load products:", error);
    document.getElementById('product-row').innerHTML = '<p class="text-danger text-center">Failed to load products. Please check the console for errors.</p>';
  }
}

/* ---------- Build UI ---------- */
function buildUI() {
  console.log("Building UI...");
  populateDropdown();
  populateBrandFilter();
  applyFiltersAndSort();
}

/* ---------- Dropdown Menu ---------- */
function populateDropdown() {
  const dropdown = document.getElementById('productsDropdown');
  dropdown.innerHTML = '<li><a href="#" class="dropdown-item" data-id="all">All Products</a></li>';
  PRODUCTS.forEach(p => {
    const li = document.createElement('li');
    li.innerHTML = `<a href="#" class="dropdown-item" data-id="${p.id}">${escapeHtml(p.name)}</a>`;
    dropdown.appendChild(li);
  });

  dropdown.addEventListener('click', (e) => {
    e.preventDefault();
    if (e.target.matches('.dropdown-item')) {
      const productId = e.target.getAttribute('data-id');
      document.getElementById('brandFilter').value = 'all'; // Reset other filters
      document.getElementById('sortSelect').value = 'default';
      applyFiltersAndSort(productId);
    }
  });
}

/* ---------- Brand Filter ---------- */
function populateBrandFilter() {
  const brandFilter = document.getElementById('brandFilter');
  const brands = [...new Set(PRODUCTS.map(p => p.brand))];
  brands.sort().forEach(brand => {
    const option = new Option(brand, brand);
    brandFilter.add(option);
  });
}

/* ---------- Apply Filters & Sort ---------- */
function applyFiltersAndSort(singleProductId = null) {
  let productsToRender = [...PRODUCTS];

  if (singleProductId && singleProductId !== 'all') {
    productsToRender = PRODUCTS.filter(p => p.id == singleProductId);
     document.getElementById('pageTitle').textContent = productsToRender[0]?.name || 'Product';
  } else {
     document.getElementById('pageTitle').textContent = 'Products';
  }

  const brand = document.getElementById('brandFilter').value;
  if (brand !== 'all') {
    productsToRender = productsToRender.filter(p => p.brand === brand);
  }

  const sortValue = document.getElementById('sortSelect').value;
  switch (sortValue) {
    case 'price-asc':
      productsToRender.sort((a, b) => a.price - b.price);
      break;
    case 'price-desc':
      productsToRender.sort((a, b) => b.price - a.price);
      break;
    case 'name-az':
      productsToRender.sort((a, b) => a.name.localeCompare(b.name));
      break;
    case 'name-za':
      productsToRender.sort((a, b) => b.name.localeCompare(a.name));
      break;
  }

  renderProducts(productsToRender);
}

/* ---------- Render Products ---------- */
function renderProducts(products) {
  console.log(`Rendering ${products.length} products...`);
  const productRow = document.getElementById('product-row');
  productRow.innerHTML = '';
  if (products.length === 0) {
      productRow.innerHTML = '<p class="text-center w-100">No products found matching your criteria.</p>';
      return;
  }
  products.forEach(p => {
    const likeInfo = state.likes[p.id] || { count: 0, liked: false };
    const rating = state.ratings[p.id] || 0;

    const starsHtml = [1, 2, 3, 4, 5].map(star =>
      `<span class="star ${star <= rating ? 'selected' : ''}" data-value="${star}">★</span>`
    ).join('');

    const cardHtml = `
      <div class="col-lg-4 col-md-6 mb-4">
        <div class="product-card card h-100">
            <div class="flip-wrapper">
                <div class="flip-inner">
                    <div class="flip-front">
                        <img src="${escapeHtml(p.img)}" class="card-img-top" alt="${escapeHtml(p.name)}">
                    </div>
                    <div class="flip-back">
                        <p class="m-0">${escapeHtml(p.description)}</p>
                    </div>
                </div>
            </div>
            <div class="card-body d-flex flex-column" data-product-id="${p.id}">
                <h5 class="card-title">${escapeHtml(p.name)}</h5>
                <p class="card-price">₹${p.price.toLocaleString('en-IN')}</p>
                <div class="rating mb-2">${starsHtml}</div>
                <div class="mt-auto d-flex justify-content-between align-items-center">
                    <button class="btn like-btn ${likeInfo.liked ? 'liked' : ''}">❤ <span class="like-count">${likeInfo.count}</span></button>
                    <button class="btn btn-add add-to-cart-btn">Add to Cart</button>
                </div>
            </div>
        </div>
      </div>
    `;
    productRow.innerHTML += cardHtml;
  });
}

/* ---------- Attach Handlers ---------- */
function attachHandlers() {
  const productRow = document.getElementById('product-row');
  productRow.addEventListener('click', e => {
    const cardBody = e.target.closest('.card-body');
    if (!cardBody) return;
    const id = cardBody.dataset.productId;

    // Like button
    if (e.target.closest('.like-btn')) {
      const likeButton = e.target.closest('.like-btn');
      const likeInfo = state.likes[id] || { count: 0, liked: false };
      
      likeInfo.count++;
      likeInfo.liked = true;
      likeButton.classList.add('liked');
      
      state.likes[id] = likeInfo;
      likeButton.querySelector('.like-count').textContent = likeInfo.count;
      localStorage.setItem('likes', JSON.stringify(state.likes));
    }

    // Add to cart
    if (e.target.closest('.add-to-cart-btn')) {
      addToCart(id);
    }
    
    // Rating stars
    if (e.target.matches('.star')) {
        const ratingValue = parseInt(e.target.dataset.value, 10);
        state.ratings[id] = ratingValue;
        const starContainer = e.target.parentElement;
        
        // *** STAR RATING FIX: Explicitly add/remove class ***
        starContainer.querySelectorAll('.star').forEach((star, index) => {
            if (index < ratingValue) {
                star.classList.add('selected');
            } else {
                star.classList.remove('selected');
            }
        });
        localStorage.setItem('ratings', JSON.stringify(state.ratings));
    }
  });
}


/* ---------- Cart Functions ---------- */
function addToCart(id) {
  const product = PRODUCTS.find(p => p.id == id);
  if (!product) return;

  const cartItem = state.cart.find(item => item.id == id);
  if (!cartItem) {
    state.cart.push({ id: product.id, name: product.name, price: product.price, img: product.img });
    localStorage.setItem('cart', JSON.stringify(state.cart));
    updateCartBadge();
    renderCart();
    showToast(`"${product.name}" added to cart.`);
  } else {
    showToast(`"${product.name}" is already in your cart.`);
  }
}

function removeFromCart(id) {
    state.cart = state.cart.filter(item => item.id != id);
    localStorage.setItem('cart', JSON.stringify(state.cart));
    updateCartBadge();
    renderCart();
}

function renderCart() {
  const cartBody = document.getElementById('cartBody');
  const cartTotalEl = document.getElementById('cartTotal');
  cartBody.innerHTML = '';
  let total = 0;

  if (state.cart.length === 0) {
      cartBody.innerHTML = '<tr><td colspan="4" class="text-center">Your cart is empty.</td></tr>';
      cartTotalEl.textContent = '₹0';
      return;
  }

  state.cart.forEach(item => {
    total += item.price;
    const row = `
      <tr>
        <td><img src="${escapeHtml(item.img)}" alt="${escapeHtml(item.name)}" width="50"></td>
        <td>${escapeHtml(item.name)}</td>
        <td>₹${item.price.toLocaleString('en-IN')}</td>
        <td><button class="btn btn-danger btn-sm" onclick="removeFromCart(${item.id})">Remove</button></td>
      </tr>
    `;
    cartBody.innerHTML += row;
  });

  cartTotalEl.textContent = `₹${total.toLocaleString('en-IN')}`;
}

function updateCartBadge() {
  document.getElementById('cartBadge').textContent = state.cart.length;
}

function showToast(message) {
  const toastEl = document.getElementById('cartToast');
  document.getElementById('cartToastBody').textContent = message;
  const toast = new bootstrap.Toast(toastEl);
  toast.show();
}

/* ---------- Utils ---------- */
function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, m =>
    ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[m]));
}

function setupNavigation() {
    const navLinks = document.querySelectorAll('.main-nav a');
    const sections = {
        productsSection: document.getElementById('productsSection'),
        cartSection: document.getElementById('cartSection'),
        contactSection: document.getElementById('contact'),
        toolbar: document.getElementById('toolbar')
    };

    navLinks.forEach(link => {
        link.addEventListener('click', e => {
            const targetId = e.target.getAttribute('href');
            
            // Hide all main sections first
            Object.values(sections).forEach(section => {
                if(section) section.style.display = 'none';
            });
            
            // Show the target section
            if (targetId === '#cartSection') {
                if(sections.cartSection) sections.cartSection.style.display = 'block';
            } else if (targetId === '#contact') {
                if(sections.contactSection) sections.contactSection.style.display = 'block';
            } else { // Default to products view
                if(sections.productsSection) sections.productsSection.style.display = 'block';
                if(sections.toolbar) sections.toolbar.style.display = 'block';
            }
        });
    });
}

function clearAllFilters() {
    document.getElementById('brandFilter').value = 'all';
    document.getElementById('sortSelect').value = 'default';
    applyFiltersAndSort();
}

/* ---------- Init ---------- */
document.addEventListener('DOMContentLoaded', async () => {
  console.log("DOMContentLoaded event fired. Initializing application.");
  await loadProducts();
  buildUI();
  renderCart();
  updateCartBadge();
  attachHandlers();
  setupNavigation();
  
  // Initially hide cart and contact
  document.getElementById('cartSection').style.display = 'none';
  const contactSection = document.getElementById('contact');
  if(contactSection) contactSection.style.display = 'none';
  
  document.getElementById('sortSelect').addEventListener('change', () => applyFiltersAndSort());
  document.getElementById('brandFilter').addEventListener('change', () => applyFiltersAndSort());
  document.getElementById('clearFilters').addEventListener('click', clearAllFilters);
});