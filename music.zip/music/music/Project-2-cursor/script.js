// State
let movies = [];
let cart = JSON.parse(localStorage.getItem('movieCart')) || [];
let currentFilter = 'all';
let currentSort = 'name';

// Load movies
async function loadMovies() {
  try {
    const response = await fetch('movies.json');
    movies = await response.json();
    
    // Initialize like counts to 0 for each movie (no persistence)
    movies.forEach(movie => {
      movie.likeCount = 0;
      movie.liked = false;
    });
    
    renderMovies();
    populateDropdown();
  } catch (error) {
    console.error('Error loading movies:', error);
  }
}
// Render movie cards
function renderMovies() {
  const container = document.getElementById('product-container') || document.getElementById('movie-list');
  if (!container) return;

  let filteredMovies = [...movies];

  // Apply filter
  if (currentFilter !== 'all') {
    filteredMovies = filteredMovies.filter(movie => movie.type === currentFilter);
  }

  // Apply sort
  filteredMovies.sort((a, b) => {
    switch (currentSort) {
      case 'name':
        return a.name.localeCompare(b.name);
      case 'price-asc':
        return a.price - b.price;
      case 'price-desc':
        return b.price - a.price;
      default:
        return 0;
    }
  });

  container.innerHTML = filteredMovies.map(movie => `
    <div class="col">
      <div class="card h-100 flip-card">
        <div class="flip-card-inner">
          <div class="flip-front">
            <img src="${escapeHtml(movie.image)}" alt="${escapeHtml(movie.name)}" class="card-img-top">
          </div>
          <div class="flip-back">
            <img src="${escapeHtml(movie.backImage)}" alt="${escapeHtml(movie.name)} - Back" class="card-img-top">
          </div>
        </div>
        <div class="movie-details">
          <div class="movie-type">${escapeHtml(movie.type)}</div>
          <div class="stars">${renderStars(movie.rating)}</div>
          <h5 class="card-title">${escapeHtml(movie.name)}</h5>
          <div class="price">₹${movie.price}</div>
          <div class="d-flex justify-content-between align-items-center">
            <button class="btn btn-primary btn-sm" onclick="addToCart(${movie.id})">
              Add to Cart
            </button>
            <button class="like-btn" onclick="toggleLike(${movie.id})">
              <span class="heart" style="color: ${movie.likeCount > 0 ? 'var(--heart)' : 'inherit'}">${movie.likeCount > 0 ? '♥' : '♡'}</span>
              <span class="like-count">${movie.likeCount || 0}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `).join('');
}

// Stars
function renderStars(rating) {
  return '★'.repeat(rating) + '☆'.repeat(5 - rating);
}

// Sort
function sortProducts(sortType) {
  currentSort = sortType;
  renderMovies();
}

// Filter
function filterByType(type) {
  currentFilter = type;
  renderMovies();
}

// Likes
function toggleLike(movieId) {
  const movie = movies.find(m => m.id === movieId);
  if (movie) {
    // Initialize likeCount if it doesn't exist
    if (movie.likeCount === undefined) {
      movie.likeCount = 0;
    }
    
    // Always increment the like count on each click
    movie.likeCount++;
    movie.liked = true; // Always set to liked when clicked
    
    // Update the UI
    const likeBtn = event.currentTarget;
    const heart = likeBtn.querySelector('.heart');
    const likeCount = likeBtn.querySelector('.like-count');
    
    heart.textContent = '♥';
    heart.style.color = 'var(--heart)';
    likeCount.textContent = movie.likeCount;
  }
}

// Cart
function addToCart(movieId) {
  const movie = movies.find(m => m.id === movieId);
  if (!movie) return;

  const existingItem = cart.find(item => item.id === movieId);
  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({
      id: movie.id,
      name: movie.name,
      price: movie.price,
      quantity: 1
    });
  }

  updateCart();
  saveCartToStorage();
  showToast('Ticket Added ✅');
}

// Change Quantity
function changeQuantity(movieId, change) {
  const item = cart.find(item => item.id === movieId);
  if (!item) return;

  item.quantity += change;
  if (item.quantity <= 0) {
    removeFromCart(movieId);
  } else {
    updateCart();
    saveCartToStorage();
  }
}

// Remove Quantity
function removeFromCart(movieId) {
  cart = cart.filter(item => item.id !== movieId);
  updateCart();
  saveCartToStorage();
}

// Save cart to localStorage
function saveCartToStorage() {
  localStorage.setItem('movieCart', JSON.stringify(cart));
}


// Update cart
function updateCart() {
  const cartBody = document.getElementById('cart-body');
  const cartCount = document.getElementById('cart-count');
  const totalCost = document.getElementById('total-cost');

  if (!cartBody || !cartCount || !totalCost) return;

  if (cart.length === 0) {
    cartBody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">Your cart is empty.</td></tr>';
    cartCount.textContent = '0';
    totalCost.textContent = '₹0';
    return;
  }

  cartBody.innerHTML = cart.map(item => `
    <tr>
      <td>${escapeHtml(item.name)}</td>
      <td>
        <div class="btn-group btn-group-sm">
          <button class="btn btn-outline-secondary" onclick="changeQuantity(${item.id}, -1)">-</button>
          <span class="btn btn-outline-secondary disabled">${item.quantity}</span>
          <button class="btn btn-outline-secondary" onclick="changeQuantity(${item.id}, 1)">+</button>
        </div>
      </td>
      <td>₹${item.price}</td>
      <td>₹${item.price * item.quantity}</td>
      <td>
        <button class="btn btn-danger btn-sm" onclick="removeFromCart(${item.id})">
          Remove
        </button>
      </td>
    </tr>
  `).join('');

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  cartCount.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
  totalCost.textContent = `₹${total}`;
}

// Toast message that means after booking ticket show message ticket booked
function showToast(message) {
  const toast = document.getElementById('toast');
  if (!toast) return;

  toast.textContent = message;
  toast.classList.add('show');
  
  setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}

// Escape HTML
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Populate dropdown menu
// function populateDropdown() {
//   const dropdown = document.querySelector('.dropdown-menu');
//   if (!dropdown) return;

//   const types = [...new Set(movies.map(movie => movie.type))];
//   dropdown.innerHTML = types.map(type => `
//     <li><a class="dropdown-item" href="movies.html?type=${encodeURIComponent(type)}">${escapeHtml(type)}</a></li>
//   `).join('');
// }

// Filter by query string (for movies.html)
function filterByQueryString() {
  const urlParams = new URLSearchParams(window.location.search);
  const type = urlParams.get('type');
  if (type) {
    currentFilter = type;
    const pageTitle = document.getElementById('page-title');
    if (pageTitle) {
      pageTitle.textContent = `${type} Movies`;
    }
  }
}

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
  loadMovies();
  filterByQueryString();
  updateCart(); // Initialize cart display with saved data
});