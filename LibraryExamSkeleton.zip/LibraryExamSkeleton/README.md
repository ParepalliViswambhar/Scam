# 📘 Library Management System

A comprehensive Library Management System built with Spring Boot, MySQL, and Docker, featuring a multi-service architecture with API, Database, and UI components.

## Project Overview

This project demonstrates a complete Library Management System with:
- **REST API** built with Spring Boot
- **MySQL Database** for data persistence
- **Web UI** for user interaction
- **Docker Compose** for orchestration
- **Multi-service architecture** with proper networking

## Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Library UI    │    │   Library API   │    │   MySQL DB      │
│   (Nginx)       │◄──►│   (Spring Boot) │◄──►│   (Database)    │
│   Port: 80      │    │   Port: 8080    │    │   Port: 3306    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## Features

- **📚 Book Management**: Add, update, delete, and search books
- **👥 Member Management**: Manage library members and their information
- **📖 Borrowing System**: Track book borrowings and returns
- **🔍 Search & Filter**: Find books and members easily
- **📊 Database Integration**: Persistent data storage with MySQL
- **🌐 REST API**: RESTful endpoints for all operations
- **🐳 Dockerized**: Easy deployment with Docker Compose

## Technology Stack

- **Backend**: Spring Boot 2.7.14, Java 11
- **Database**: MySQL 8.0
- **Frontend**: HTML5, CSS3, JavaScript
- **Web Server**: Nginx (for UI)
- **Containerization**: Docker, Docker Compose
- **Build Tool**: Maven 3.6+

## Prerequisites

- Docker Desktop
- Docker Compose
- Java 11 (for local development)
- Maven 3.6+ (for local development)

## Quick Start

### Using Docker Compose (Recommended)

1. **Clone and navigate to the project:**
   ```bash
   cd LibraryExamSkeleton
   ```

2. **Build and start all services:**
   ```bash
   docker-compose up --build
   ```

3. **Access the application:**
   - **UI**: http://localhost
   - **API**: http://localhost:8080/api
   - **Database**: localhost:3306

4. **Stop the services:**
   ```bash
   docker-compose down
   ```

### Local Development

1. **Build the API:**
   ```bash
   cd library-api
   mvn clean package
   ```

2. **Run the API:**
   ```bash
   java -jar target/library-api-1.0.0.jar
   ```

3. **Start MySQL database:**
   ```bash
   docker run -d --name library-mysql \
     -e MYSQL_ROOT_PASSWORD=rootpassword \
     -e MYSQL_DATABASE=library_db \
     -p 3306:3306 \
     -v $(pwd)/library-db/init.sql:/docker-entrypoint-initdb.d/init.sql \
     mysql:8.0
   ```

## API Endpoints

### Health Check
- `GET /api/status` - API status check
- `GET /api/hello` - Simple hello message

### Books (Future Implementation)
- `GET /api/books` - Get all books
- `POST /api/books` - Add new book
- `GET /api/books/{id}` - Get book by ID
- `PUT /api/books/{id}` - Update book
- `DELETE /api/books/{id}` - Delete book

### Members (Future Implementation)
- `GET /api/members` - Get all members
- `POST /api/members` - Add new member
- `GET /api/members/{id}` - Get member by ID
- `PUT /api/members/{id}` - Update member
- `DELETE /api/members/{id}` - Delete member

## Database Schema

### Books Table
```sql
CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    isbn VARCHAR(20) UNIQUE,
    published_year INT,
    available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Members Table
```sql
CREATE TABLE members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    membership_date DATE DEFAULT (CURRENT_DATE),
    active BOOLEAN DEFAULT TRUE
);
```

### Borrowings Table
```sql
CREATE TABLE borrowings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT,
    member_id INT,
    borrow_date DATE DEFAULT (CURRENT_DATE),
    return_date DATE,
    due_date DATE,
    status ENUM('BORROWED', 'RETURNED', 'OVERDUE') DEFAULT 'BORROWED',
    FOREIGN KEY (book_id) REFERENCES books(id),
    FOREIGN KEY (member_id) REFERENCES members(id)
);
```

## Project Structure

```
LibraryExamSkeleton/
├── library-api/                 # Spring Boot API
│   ├── src/main/java/com/library/
│   │   ├── LibraryApplication.java
│   │   └── controller/
│   │       └── LibraryController.java
│   ├── pom.xml
│   └── Dockerfile
├── library-db/                  # Database setup
│   └── init.sql
├── library-ui/                  # Frontend
│   └── index.html
├── docker-compose.yml           # Multi-service orchestration
└── README.md
```

## Configuration

### Environment Variables

**API Service:**
- `SPRING_DATASOURCE_URL`: Database connection URL
- `SPRING_DATASOURCE_USERNAME`: Database username
- `SPRING_DATASOURCE_PASSWORD`: Database password
- `SPRING_JPA_HIBERNATE_DDL_AUTO`: Hibernate DDL mode

**Database Service:**
- `MYSQL_ROOT_PASSWORD`: Root password
- `MYSQL_DATABASE`: Database name
- `MYSQL_USER`: Database user
- `MYSQL_PASSWORD`: Database password

## Development

### Building the Project

```bash
# Build API
cd library-api
mvn clean package

# Build Docker image
docker build -t library-api .
```

### Running Tests

```bash
cd library-api
mvn test
```

### Database Management

```bash
# Connect to MySQL
docker exec -it library-mysql mysql -u library_user -p library_db

# View logs
docker logs library-mysql
```

## Troubleshooting

### Common Issues

1. **Port conflicts:**
   ```bash
   # Check port usage
   netstat -ano | findstr :8080
   netstat -ano | findstr :3306
   ```

2. **Database connection issues:**
   - Ensure MySQL container is running
   - Check database credentials
   - Verify network connectivity

3. **API not responding:**
   - Check API container logs: `docker logs library-api-service`
   - Verify database is accessible
   - Check health endpoint: `curl http://localhost:8080/api/status`

4. **UI not loading:**
   - Check Nginx container: `docker logs library-ui-service`
   - Verify file permissions
   - Check browser console for errors

### Docker Commands

```bash
# View all containers
docker ps -a

# View logs
docker logs <container_name>

# Restart service
docker-compose restart <service_name>

# Rebuild and restart
docker-compose up --build <service_name>

# Clean up
docker-compose down -v
docker system prune
```

## Future Enhancements

- [ ] Complete CRUD operations for books and members
- [ ] User authentication and authorization
- [ ] Advanced search and filtering
- [ ] Email notifications for overdue books
- [ ] Reporting and analytics
- [ ] Mobile-responsive UI
- [ ] API documentation with Swagger
- [ ] Unit and integration tests
- [ ] CI/CD pipeline setup

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is for educational purposes as part of a practical exam.

## Contact

For questions or support, please contact the development team.

---

**Note**: This is a skeleton project that demonstrates proper multi-service architecture, Docker orchestration, and Spring Boot development practices. It serves as a foundation for building a comprehensive library management system.