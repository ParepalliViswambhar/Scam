# Hospital Management System

A comprehensive web-based Hospital Management System built with Java, JSP, and Maven, containerized with Docker and Tomcat.

## Project Overview

This project is a web-based Hospital Management System that provides a foundation for managing hospital operations including patient management, doctor scheduling, appointment systems, and inventory management. The application is built using Java web technologies and deployed using Docker with Apache Tomcat.

## Features

- **Web-based Interface**: Modern, responsive JSP-based user interface
- **Patient Management**: Complete patient record management system
- **Doctor Management**: Doctor scheduling and specialty management
- **Appointment System**: Efficient appointment booking and management
- **Inventory Management**: Medical supplies and equipment tracking
- **Docker Containerization**: Easy deployment and scaling
- **Maven Build System**: Automated dependency management and building
- **Tomcat Integration**: Production-ready web server deployment

## Technology Stack

- **Backend**: Java 11
- **Frontend**: JSP, HTML5, CSS3
- **Build Tool**: Maven 3.6+
- **Web Server**: Apache Tomcat 9.0
- **Containerization**: Docker, Docker Compose
- **Testing**: JUnit 4.13.2

## Prerequisites

- Java 11 or higher
- Maven 3.6 or higher
- Docker Desktop
- Docker Compose

## Project Structure

```
HospitalMgmtSystem/
├── src/
│   └── main/
│       └── webapp/
│           ├── index.jsp
│           └── WEB-INF/
│               └── web.xml
├── target/
│   └── HospitalMgmtSystem.war
├── pom.xml
├── Dockerfile
├── docker-compose.yml
└── README.md
```

## Quick Start

### Using Docker Compose (Recommended)

1. **Build and run the application:**
   ```bash
   docker-compose up --build
   ```

2. **Run in detached mode:**
   ```bash
   docker-compose up -d --build
   ```

3. **Stop the application:**
   ```bash
   docker-compose down
   ```

4. **View logs:**
   ```bash
   docker-compose logs -f
   ```

### Using Docker Commands

1. **Build the Maven project:**
   ```bash
   mvn clean package
   ```

2. **Build the Docker image:**
   ```bash
   docker build -t hospital-mgmt-system .
   ```

3. **Run the container:**
   ```bash
   docker run -p 8080:8080 hospital-mgmt-system
   ```

4. **Run in detached mode:**
   ```bash
   docker run -d -p 8080:8080 hospital-mgmt-system
   ```

## Accessing the Application

Once the container is running, access the application at:
- **URL**: http://localhost:8080/HospitalMgmtSystem
- **Port**: 8080

## Configuration

### Maven Configuration

The project includes proper Maven configuration with:
- **Packaging**: WAR (Web Archive)
- **Java Version**: 11
- **Compiler Plugin**: Maven Compiler Plugin 3.11.0
- **War Plugin**: Maven War Plugin 3.2.3
- **Testing**: JUnit 4.13.2

### Docker Configuration

- **Base Image**: tomcat:9.0-jdk11-openjdk-slim
- **Port**: 8080
- **Deployment**: WAR file deployed to Tomcat webapps directory
- **Command**: catalina.sh run

### Docker Compose Configuration

- **Service Name**: hospital-mgmt-system
- **Container Name**: hospital-mgmt-app
- **Port Mapping**: 8080:8080
- **Restart Policy**: unless-stopped
- **Network**: hospital-network

## Development

### Building the Project

```bash
# Clean and compile
mvn clean compile

# Run tests
mvn test

# Package the application
mvn clean package

# Install dependencies
mvn install
```

### Running Tests

```bash
mvn test
```

### Local Development

1. **Start Tomcat locally:**
   ```bash
   # Deploy the WAR file to your local Tomcat installation
   cp target/HospitalMgmtSystem.war $TOMCAT_HOME/webapps/
   ```

2. **Access the application:**
   - Navigate to http://localhost:8080/HospitalMgmtSystem

## API Endpoints

The application currently provides:

- **Home Page**: `/HospitalMgmtSystem/` - Main dashboard with feature overview
- **Welcome Page**: Displays hospital management system features

## Troubleshooting

### Common Issues

1. **Port already in use:**
   ```bash
   # Check what's using port 8080
   netstat -ano | findstr :8080
   
   # Kill the process or use a different port
   docker run -p 8081:8080 hospital-mgmt-system
   ```

2. **Docker build fails:**
   - Ensure Docker Desktop is running
   - Check if Maven build was successful: `mvn clean package`
   - Verify WAR file exists in target directory

3. **Application not accessible:**
   - Check container status: `docker ps`
   - View container logs: `docker logs <container_id>`
   - Verify port mapping: `docker port <container_id>`

4. **Maven build issues:**
   - Clean and rebuild: `mvn clean package`
   - Check Java version: `java -version`
   - Verify Maven installation: `mvn -version`

### Docker Commands

```bash
# List running containers
docker ps

# View container logs
docker logs <container_id>

# Stop container
docker stop <container_id>

# Remove container
docker rm <container_id>

# Remove image
docker rmi hospital-mgmt-system

# Clean up unused resources
docker system prune
```

## Deployment

### Production Deployment

1. **Build production image:**
   ```bash
   docker build -t hospital-mgmt-system:latest .
   ```

2. **Deploy with Docker Compose:**
   ```bash
   docker-compose up -d
   ```

3. **Scale the application:**
   ```bash
   docker-compose up -d --scale hospital-mgmt-system=3
   ```

### Environment Variables

The application supports the following environment variables:
- `TZ`: Timezone (default: UTC)
- `JAVA_OPTS`: Additional JVM options

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Future Enhancements

- [ ] Database integration (MySQL/PostgreSQL)
- [ ] User authentication and authorization
- [ ] REST API endpoints
- [ ] Patient registration forms
- [ ] Doctor scheduling interface
- [ ] Appointment booking system
- [ ] Inventory management dashboard
- [ ] Reporting and analytics
- [ ] Mobile-responsive design improvements

## License

This project is for educational purposes as part of a software engineering course.

## Contact

For questions or support, please contact the development team.

---

**Note**: This is a foundational web application that demonstrates proper Java web development practices, Maven configuration, and Docker containerization. It serves as a starting point for building a comprehensive hospital management system.
