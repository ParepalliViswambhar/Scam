import java.util.Scanner;

public class LeakyBucket {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int bucketSize, outputRate, incoming, bucket = 0, time = 1;

        System.out.print("Enter bucket capacity: ");
        bucketSize = sc.nextInt();

        System.out.print("Enter output rate: ");
        outputRate = sc.nextInt();

        // Run until incoming = 0
        while (true) {
            System.out.print("\nTime " + time + " sec - Enter incoming packets (0 to stop): ");
            incoming = sc.nextInt();

            if (incoming == 0)
                break;

            // Add incoming packets
            bucket += incoming;

            // Check overflow
            if (bucket > bucketSize) {
                System.out.println("Bucket overflow! Packets dropped: " + (bucket - bucketSize));
                bucket = bucketSize;
            }

            // Leak/output packets
            int sent = Math.min(bucket, outputRate);
            bucket -= sent;

            System.out.println("Packets sent: " + sent + " | Packets left in bucket: " + bucket);

            time++;
        }

        // Leak remaining packets
        while (bucket > 0) {
            int sent = Math.min(bucket, outputRate);
            bucket -= sent;

            System.out.println("\nLeaking... Packets sent: " + sent + " | Packets left: " + bucket);
        }

        System.out.println("\n\nTransmission complete!");

        sc.close();
    }
}
