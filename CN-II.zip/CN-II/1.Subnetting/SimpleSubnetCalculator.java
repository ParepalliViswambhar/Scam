import java.util.*;

public class SimpleSubnetCalculator {

    // Convert IP to array of integers
    public static int[] parseIP(String ip) {
        String[] parts = ip.split("\\.");
        return new int[]{
            Integer.parseInt(parts[0]),
            Integer.parseInt(parts[1]),
            Integer.parseInt(parts[2]),
            Integer.parseInt(parts[3])
        };
    }

    // Convert integer array back to IP string
    public static String toIP(int[] arr) {
        return arr[0] + "." + arr[1] + "." + arr[2] + "." + arr[3];
    }

    // Convert IP array to a single integer
    public static int toInt(int[] ip) {
        return (ip[0] << 24) | (ip[1] << 16) | (ip[2] << 8) | ip[3];
    }

    // Convert integer back to IP array
    public static int[] toArray(int num) {
        return new int[]{
            (num >> 24) & 255,
            (num >> 16) & 255,
            (num >> 8) & 255,
            num & 255
        };
    }

    // Convert prefix /n into mask integer
    public static int prefixToMask(int prefix) {
        return prefix == 0 ? 0 : ~((1 << (32 - prefix)) - 1);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter IP address: ");
        String ipString = sc.next();

        System.out.print("Enter prefix length: ");
        int prefix = sc.nextInt();

        int newPrefix = prefix + 1; // split into 2 subnets

        int[] ipArr = parseIP(ipString);
        int ipInt = toInt(ipArr);

        int mask = prefixToMask(prefix);
        int newMask = prefixToMask(newPrefix);

        int subnetSize = 1 << (32 - newPrefix);  // total addresses in subnet

        System.out.println("\nNumber of subnets: 2");
        System.out.println("Hosts per subnet: " + (subnetSize - 2));

        // Base network address
        int baseNetwork = ipInt & mask;

        for (int i = 0; i < 2; i++) {
            int network = baseNetwork + (i * subnetSize);
            int broadcast = network + subnetSize - 1;

            int firstHost = network + 1;
            int lastHost = broadcast - 1;

            System.out.println("\nSubnet " + (i + 1));
            System.out.println("Network:   " + toIP(toArray(network)));
            System.out.println("Broadcast: " + toIP(toArray(broadcast)));
            System.out.println("First Host: " + toIP(toArray(firstHost)));
            System.out.println("Last Host:  " + toIP(toArray(lastHost)));
            System.out.println("Subnet Mask: " + toIP(toArray(newMask)));
        }

        sc.close();
    }
}
