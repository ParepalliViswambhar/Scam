import java.util.Scanner;

public class BitwiseString {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String str = sc.nextLine();  // reads full line including spaces

        System.out.println("\nOriginal String: " + str);
        System.out.println("Character\tASCII\tAND(127)\tXOR(127)");
        System.out.println("---------------------------------------------");

        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);

            int ascii = (int) ch;
            int andResult = ch & 127;
            int xorResult = ch ^ 127;

            System.out.printf("   %c\t\t%d\t   %d\t\t   %d\n",
                    ch, ascii, andResult, xorResult);
        }

        sc.close();
    }
}
